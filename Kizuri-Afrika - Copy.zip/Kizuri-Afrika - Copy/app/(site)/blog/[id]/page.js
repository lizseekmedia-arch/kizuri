import { notFound } from 'next/navigation';
import RevealInit from '../../../../components/RevealInit';
import CommentForm from '../../../../components/CommentForm';
import { getPostById, getApprovedComments } from '../../../../lib/posts';
import { CATEGORY_NAMES } from '../../../../lib/categories';

export const revalidate = 0;

export async function generateMetadata({ params }) {
  const post = await getPostById(params.id);
  if (!post) return { title: 'Story Not Found — Kizuri Afrika' };
  return {
    title: `${post.title} — Kizuri Afrika`,
    description: post.excerpt || undefined,
  };
}

export default async function BlogPostPage({ params }) {
  const post = await getPostById(params.id);
  if (!post) notFound();

  const comments = await getApprovedComments(post.id);

  return (
    <div id="post-content-area">
      <RevealInit />
      <article className="post-detail-container">
        <a href="/blog" className="post-back-btn">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" style={{ verticalAlign: 'middle' }}>
            <line x1="19" y1="12" x2="5" y2="12" />
            <polyline points="12 19 5 12 12 5" />
          </svg>
          Back to Journal
        </a>

        <div className="post-header">
          <span className="post-category-tag">{CATEGORY_NAMES[post.category] || post.category}</span>
          <h1 className="post-detail-title">{post.title}</h1>
          {post.subtitle && <p className="post-detail-subtitle">{post.subtitle}</p>}
          <div className="post-meta-bar">
            <span>By <strong>{post.author || 'Kizuri Afrika'}</strong></span>
            <span>&middot;</span>
            <span>{post.date}</span>
            <span>&middot;</span>
            <span>{post.read_time || '3 min read'}</span>
          </div>
        </div>

        <img src={post.image || '/images/hero_bg.png'} alt={post.title} className="post-main-img" />

        <div className="post-content" dangerouslySetInnerHTML={{ __html: post.content }} />

        {post.tags && post.tags.length > 0 && (
          <div className="post-tags">
            {post.tags.map((tag) => (
              <span key={tag} className="post-tag">#{tag}</span>
            ))}
          </div>
        )}

        <section className="comments-container">
          <h2 className="comments-count-title">
            {comments.length} Comment{comments.length !== 1 ? 's' : ''}
          </h2>

          <div className="comments-list">
            {comments.length === 0 ? (
              <p style={{ color: 'var(--warm-mid)', fontStyle: 'italic', fontSize: 14 }}>
                Be the first to share your perspective.
              </p>
            ) : (
              comments.map((comment) => (
                <div key={comment.id} className="comment-card">
                  <div className="comment-card-header">
                    <span className="comment-author">{comment.name}</span>
                    <span className="comment-date">
                      {new Date(comment.created_at).toLocaleDateString('en-US', {
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric',
                      })}
                    </span>
                  </div>
                  <div className="comment-text">
                    {comment.text.split('\n').map((line, i, arr) => (
                      <span key={i}>
                        {line}
                        {i < arr.length - 1 && <br />}
                      </span>
                    ))}
                  </div>
                </div>
              ))
            )}
          </div>

          <CommentForm postId={post.id} />
        </section>
      </article>
    </div>
  );
}
