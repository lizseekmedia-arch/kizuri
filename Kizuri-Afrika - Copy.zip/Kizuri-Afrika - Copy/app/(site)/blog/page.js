import Link from 'next/link';
import RevealInit from '../../../components/RevealInit';
import PostCard from '../../../components/PostCard';
import { getAllPosts } from '../../../lib/posts';
import { CATEGORY_NAMES, CATEGORY_OPTIONS } from '../../../lib/categories';

export const metadata = {
  title: 'Blog — Kizuri Afrika',
  description:
    "Explore Kizuri Afrika's blog. Insights, stories, and inspirations on African Style, Home, Art, Table, and cultural reflections.",
};

export const revalidate = 0;

export default async function BlogListPage({ searchParams }) {
  const activeCategory = searchParams?.category && CATEGORY_NAMES[searchParams.category] ? searchParams.category : 'all';
  const posts = await getAllPosts();
  const filteredPosts = activeCategory === 'all' ? posts : posts.filter((p) => p.category === activeCategory);

  return (
    <>
      <RevealInit deps={[activeCategory]} />

      <header className="subpage-header">
        <p>Perspectives &amp; Reflections</p>
        <h1>The Kizuri Journal</h1>
        <div style={{ width: 60, height: 1, background: 'var(--gold)', margin: '32px auto 0' }} />
      </header>

      <div className="blog-filters">
        <Link href="/blog" className={`filter-btn${activeCategory === 'all' ? ' active' : ''}`}>All</Link>
        {CATEGORY_OPTIONS.map((cat) => (
          <Link
            key={cat}
            href={`/blog?category=${cat}`}
            className={`filter-btn${activeCategory === cat ? ' active' : ''}`}
          >
            {cat === 'edit' ? 'The Edit' : CATEGORY_NAMES[cat]}
          </Link>
        ))}
      </div>

      <section className="blog-grid-section">
        {filteredPosts.length === 0 ? (
          <div style={{ textAlign: 'center', padding: 48, color: 'var(--warm-mid)' }}>
            <p>No stories found in this category. Check back soon.</p>
          </div>
        ) : (
          <div className="blog-list-grid">
            {filteredPosts.map((post) => (
              <PostCard key={post.id} post={post} />
            ))}
          </div>
        )}
      </section>
    </>
  );
}
