import RevealInit from '../../components/RevealInit';
import PillarsMarquee from '../../components/PillarsMarquee';
import SubscribeForm from '../../components/SubscribeForm';

export default function HomePage() {
  return (
    <>
      <RevealInit />

      {/* HERO */}
      <section className="hero">
        <div className="hero-inner">
          <div className="hero-rule" />
          <h1 className="hero-wordmark">KIZURI&nbsp;&nbsp;AFRIKA</h1>
          <div className="hero-rule-bottom" />
          <p className="hero-tagline">Living Beautifully The African Way</p>
          <a href="#about" className="hero-cta">Enter the world</a>
        </div>
        <div className="hero-scroll">
          <span>Scroll</span>
          <div className="scroll-line" />
        </div>
      </section>

      {/* INTRO / ABOUT */}
      <section className="intro" id="about">
        <span className="section-label reveal">The Brand</span>
        <h2 className="intro-heading reveal reveal-delay-1">
          Africa has always been beautiful.<br />
          We are simply refusing to whisper it.
        </h2>
        <div className="intro-rule reveal reveal-delay-2" />
        <p className="intro-body reveal reveal-delay-3">
          Kizuri Afrika is a refined African lifestyle brand that celebrates the beauty, depth, and richness of the
          continent through thoughtfully curated design, fashion, and cultural expression. Rooted in heritage yet
          elevated through a modern, minimalist lens, the brand embodies a quiet luxury aesthetic — where
          simplicity, intention, and authenticity take centre stage.
        </p>
        <br />
        <p className="intro-body reveal reveal-delay-4">
          At its core, Kizuri Afrika is about living beautifully the African way — honouring culture, embracing
          quality, and creating experiences that feel both meaningful and timeless.
        </p>
      </section>

      <PillarsMarquee />

      {/* BRAND STATEMENT */}
      <section className="statement">
        <blockquote className="statement-quote reveal reveal-delay-1">
          &ldquo;There is a way of living that is rooted, refined, and entirely our own.&rdquo;
        </blockquote>
        <p className="statement-attr reveal reveal-delay-2">Kizuri Afrika</p>
      </section>

      {/* STAY CONNECTED */}
      <section className="connect" id="connect">
        <span className="section-label reveal">Stay in the World</span>
        <h2 className="connect-heading reveal reveal-delay-1">Join the Kizuri Afrika community.</h2>
        <p className="connect-sub reveal reveal-delay-2">
          Be the first to receive new stories, curated inspirations, and invitations into the world of Kizuri
          Afrika.
        </p>

        <SubscribeForm />

        <p className="connect-note reveal reveal-delay-4">No noise. Only beauty.</p>

        <div className="social-links reveal" style={{ marginTop: 24, gap: 24, flexWrap: 'wrap', justifyContent: 'center' }}>
          <a href="mailto:hello@kizuriafrika.com" className="social-link">
            hello@kizuriafrika.com
          </a>
          <span className="social-divider" />
          <a href="https://wa.me/254711434927" target="_blank" rel="noopener noreferrer" className="social-link">
            WhatsApp: +254711434927
          </a>
        </div>
      </section>
    </>
  );
}
