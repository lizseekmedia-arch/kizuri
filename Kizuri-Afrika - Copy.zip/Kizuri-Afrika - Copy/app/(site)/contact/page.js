import RevealInit from '../../../components/RevealInit';
import ContactForm from '../../../components/ContactForm';

export const metadata = {
  title: 'Connect — Kizuri Afrika',
  description: 'Connect with Kizuri Afrika. Get in touch with our team for inquiries, collaboration, or general questions.',
};

export default function ContactPage() {
  return (
    <>
      <RevealInit />

      <header className="subpage-header">
        <p>Get in Touch</p>
        <h1>Let&apos;s Tell Africa&apos;s Story Beautifully</h1>
        <div style={{ width: 60, height: 1, background: 'var(--gold)', margin: '32px auto 0' }} />
      </header>

      <main className="contact-grid">
        <section className="contact-info-panel reveal">
          <p>
            Kizuri Afrika Living exists to celebrate the beauty, depth and richness of Africa through design,
            fashion, food, craftsmanship and cultural storytelling.
          </p>
          <p>
            We believe the continent&apos;s stories deserve to be told with excellence, dignity and pride. Through
            thoughtful editorial features, cultural preservation, meaningful collaborations and the elevation of
            African makers, we are helping shape a future where African identity is not merely remembered — but
            celebrated.
          </p>
          <p>
            Whether you are an artisan, creator, brand, organisation, storyteller or fellow advocate for African
            culture, we welcome the opportunity to connect.
          </p>
          <p>Together, we can help tell Africa&apos;s story beautifully.</p>

          <ul className="contact-details">
            <li>
              <span className="label">Direct Email</span>
              <a href="mailto:hello@kizuriafrika.com">hello@kizuriafrika.com</a>
            </li>
            <li>
              <span className="label">KAL WhatsApp</span>
              <a href="https://wa.me/254711434927" target="_blank" rel="noopener noreferrer">+254711434927</a>
            </li>
            <li>
              <span className="label">Instagram</span>
              <a href="https://www.instagram.com/kizuri.afrika" target="_blank" rel="noopener noreferrer">@kizuri.afrika</a>
            </li>
          </ul>
        </section>

        <section className="contact-form-panel reveal reveal-delay-1">
          <ContactForm />
        </section>
      </main>
    </>
  );
}
