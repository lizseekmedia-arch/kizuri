import LoginForm from '../../../components/admin/LoginForm';

export const metadata = {
  title: 'Admin Access — Kizuri Afrika',
  robots: { index: false, follow: false },
};

export default function AdminLoginPage() {
  return (
    <div
      style={{
        display: 'flex',
        minHeight: '100vh',
        alignItems: 'center',
        justifyContent: 'center',
        background: '#111',
      }}
    >
      <div
        className="modal-content"
        style={{
          maxWidth: 400,
          width: '100%',
          textAlign: 'center',
          border: '1px solid rgba(200, 169, 81, 0.15)',
          background: '#1A1A18',
          boxShadow: '0 24px 64px rgba(0,0,0,0.6)',
        }}
      >
        <span className="section-label" style={{ color: 'var(--gold)', marginBottom: 16 }}>Kizuri Afrika</span>
        <h2 style={{ fontFamily: 'var(--serif)', fontSize: 26, color: '#fff', marginBottom: 24, fontWeight: 300 }}>
          Admin Access
        </h2>
        <LoginForm />
      </div>
    </div>
  );
}
