import AdminNav from '../../components/admin/AdminNav';
import DashboardClient from '../../components/admin/DashboardClient';
import { getAdminDashboardData } from '../../lib/admin-data';

export const metadata = {
  title: 'Admin Dashboard — Kizuri Afrika',
  robots: { index: false, follow: false },
};

export const dynamic = 'force-dynamic';

export default async function AdminDashboardPage() {
  const { posts, comments, messages, subscriptions } = await getAdminDashboardData();

  return (
    <div style={{ background: '#111', minHeight: '100vh', color: '#eee' }}>
      <AdminNav />
      <DashboardClient posts={posts} comments={comments} messages={messages} subscriptions={subscriptions} />
    </div>
  );
}
