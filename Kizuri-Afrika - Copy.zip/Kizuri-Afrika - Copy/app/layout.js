import './globals.css';

export const metadata = {
  title: 'Kizuri Afrika — Living Beautifully The African Way',
  description:
    'Kizuri Afrika — A refined African lifestyle brand celebrating the beauty, depth, and richness of the continent through design, fashion, and cultural expression.',
  icons: {
    icon: [
      { url: '/favicon.ico', type: 'image/x-icon' },
      { url: '/kal_favicon_256.png', sizes: '256x256', type: 'image/png' },
    ],
    apple: '/kal_favicon_256.png',
  },
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,500;1,300;1,400&family=Jost:wght@300;400&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>{children}</body>
    </html>
  );
}
