'use server';
import { cookies } from 'next/headers';
import { ADMIN_COOKIE_NAME, ADMIN_COOKIE_OPTIONS, createSessionCookieValue } from '../../lib/auth';

export async function loginAction(passcode) {
  const expected = process.env.ADMIN_PASSCODE;
  if (!expected) {
    return { success: false, error: 'Server is missing ADMIN_PASSCODE configuration.' };
  }

  if (passcode !== expected) {
    return { success: false, error: 'Incorrect passcode. Please try again.' };
  }

  const value = await createSessionCookieValue();
  cookies().set(ADMIN_COOKIE_NAME, value, ADMIN_COOKIE_OPTIONS);

  return { success: true };
}

export async function logoutAction() {
  cookies().delete(ADMIN_COOKIE_NAME);
}
