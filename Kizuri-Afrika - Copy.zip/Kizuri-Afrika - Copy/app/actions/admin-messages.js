'use server';
import { revalidatePath } from 'next/cache';
import { getSupabaseAdmin } from '../../lib/supabase';
import { requireAdminSession } from '../../lib/requireAdmin';

export async function deleteMessageAction(id) {
  await requireAdminSession();
  const supabase = getSupabaseAdmin();
  const { error } = await supabase.from('messages').delete().eq('id', id);
  if (error) return { success: false, error: error.message };
  revalidatePath('/admin');
  return { success: true };
}
