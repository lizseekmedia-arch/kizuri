'use server';
import { getSupabaseAdmin, BLOG_IMAGES_BUCKET } from '../../lib/supabase';
import { requireAdminSession } from '../../lib/requireAdmin';

const MAX_BYTES = 8 * 1024 * 1024; // 8MB

export async function uploadImageAction(formData) {
  await requireAdminSession();

  const file = formData.get('file');
  if (!file || typeof file === 'string') {
    return { success: false, error: 'No file provided.' };
  }
  if (!file.type?.startsWith('image/')) {
    return { success: false, error: 'Please select an image file.' };
  }
  if (file.size > MAX_BYTES) {
    return { success: false, error: 'Image is too large (max 8MB).' };
  }

  const folder = formData.get('folder') === 'inline' ? 'inline' : 'covers';
  const safeName = file.name.replace(/[^a-zA-Z0-9.\-_]/g, '-');
  const path = `${folder}/${Date.now()}-${safeName}`;

  const supabase = getSupabaseAdmin();
  const { error: uploadError } = await supabase.storage
    .from(BLOG_IMAGES_BUCKET)
    .upload(path, file, { contentType: file.type, upsert: false });

  if (uploadError) {
    return { success: false, error: uploadError.message };
  }

  const { data } = supabase.storage.from(BLOG_IMAGES_BUCKET).getPublicUrl(path);
  return { success: true, url: data.publicUrl };
}
