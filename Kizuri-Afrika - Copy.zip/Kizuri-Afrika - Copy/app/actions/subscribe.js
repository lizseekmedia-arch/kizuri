'use server';
import { getSupabaseAdmin } from '../../lib/supabase';

export async function subscribeAction(email) {
  const trimmed = (email || '').trim();
  if (!trimmed) {
    return { success: false, error: 'Email is required.' };
  }

  const supabase = getSupabaseAdmin();
  const { error } = await supabase.from('subscriptions').insert({ email: trimmed });

  // Unique violation just means they're already subscribed — treat as success.
  if (error && error.code !== '23505') {
    return { success: false, error: error.message };
  }

  return { success: true };
}
