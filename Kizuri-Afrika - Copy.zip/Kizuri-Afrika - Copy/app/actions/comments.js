'use server';
import { getSupabaseAdmin } from '../../lib/supabase';

export async function submitCommentAction({ postId, name, text }) {
  const trimmedName = (name || '').trim();
  const trimmedText = (text || '').trim();

  if (!postId || !trimmedName || !trimmedText) {
    return { success: false, error: 'Name and comment are required.' };
  }

  const supabase = getSupabaseAdmin();
  const { error } = await supabase.from('comments').insert({
    post_id: postId,
    name: trimmedName,
    text: trimmedText,
    approved: false,
  });

  if (error) {
    return { success: false, error: error.message };
  }

  return { success: true };
}
