'use server';
import { revalidatePath } from 'next/cache';
import { getSupabaseAdmin } from '../../lib/supabase';
import { requireAdminSession } from '../../lib/requireAdmin';

function slugify(title) {
  return title
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '');
}

export async function savePostAction(post, editId) {
  await requireAdminSession();

  const title = (post.title || '').trim();
  if (!title) return { success: false, error: 'Title is required.' };

  const supabase = getSupabaseAdmin();
  const id = editId || slugify(title);

  let content = post.content || '';
  if (content && !content.includes('<p>') && !content.includes('<h1') && !content.includes('<h2')) {
    content = content
      .trim()
      .split(/\n\s*\n/)
      .map((block) => {
        const trimmed = block.trim();
        if (!trimmed) return '';
        if (trimmed.startsWith('<blockquote>') || trimmed.startsWith('<img') || trimmed.startsWith('<figure')) {
          return trimmed;
        }
        return `<p>${trimmed.replace(/\n/g, '<br />')}</p>`;
      })
      .filter(Boolean)
      .join('\n\n');
  }

  const row = {
    id,
    title,
    subtitle: (post.subtitle || '').trim(),
    category: post.category,
    author: 'Kizuri Afrika',
    date: (post.date || '').trim(),
    read_time: (post.readTime || '').trim() || '3 min read',
    image: (post.image || '').trim(),
    excerpt: (post.excerpt || '').trim(),
    content,
    tags: post.tags || [],
  };

  if (!editId) {
    const { data: existing } = await supabase.from('posts').select('id').eq('id', id).maybeSingle();
    if (existing) {
      return { success: false, error: 'A post with this title already exists. Please choose a unique title.' };
    }
  }

  const { error } = await supabase.from('posts').upsert(row, { onConflict: 'id' });
  if (error) return { success: false, error: error.message };

  revalidatePath('/blog');
  revalidatePath(`/blog/${id}`);
  revalidatePath('/admin');

  return { success: true, id };
}

export async function deletePostAction(id) {
  await requireAdminSession();

  const supabase = getSupabaseAdmin();
  const { error } = await supabase.from('posts').delete().eq('id', id);
  if (error) return { success: false, error: error.message };

  revalidatePath('/blog');
  revalidatePath('/admin');
  return { success: true };
}
