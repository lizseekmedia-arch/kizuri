'use server';
import { revalidatePath } from 'next/cache';
import { getSupabaseAdmin } from '../../lib/supabase';
import { requireAdminSession } from '../../lib/requireAdmin';

export async function setCommentApprovalAction(id, approved) {
  await requireAdminSession();
  const supabase = getSupabaseAdmin();
  const { data, error } = await supabase
    .from('comments')
    .update({ approved })
    .eq('id', id)
    .select('post_id')
    .maybeSingle();
  if (error) return { success: false, error: error.message };

  if (data?.post_id) revalidatePath(`/blog/${data.post_id}`);
  revalidatePath('/admin');
  return { success: true };
}

export async function deleteCommentAction(id) {
  await requireAdminSession();
  const supabase = getSupabaseAdmin();
  const { data, error } = await supabase
    .from('comments')
    .delete()
    .eq('id', id)
    .select('post_id')
    .maybeSingle();
  if (error) return { success: false, error: error.message };

  if (data?.post_id) revalidatePath(`/blog/${data.post_id}`);
  revalidatePath('/admin');
  return { success: true };
}
