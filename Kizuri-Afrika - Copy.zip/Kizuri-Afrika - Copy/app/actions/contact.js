'use server';
import { getSupabaseAdmin } from '../../lib/supabase';

export async function submitContactAction({ name, email, phone, linkedin, message }) {
  const trimmedName = (name || '').trim();
  const trimmedEmail = (email || '').trim();
  const trimmedMessage = (message || '').trim();

  if (!trimmedName || !trimmedEmail || !trimmedMessage) {
    return { success: false, error: 'Name, email, and message are required.' };
  }

  const supabase = getSupabaseAdmin();
  const { error } = await supabase.from('messages').insert({
    name: trimmedName,
    email: trimmedEmail,
    phone: (phone || '').trim(),
    linkedin: (linkedin || '').trim(),
    message: trimmedMessage,
  });

  if (error) {
    return { success: false, error: error.message };
  }

  return { success: true };
}
