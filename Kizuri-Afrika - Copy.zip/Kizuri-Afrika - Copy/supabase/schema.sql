-- Kizuri Afrika — Supabase schema
-- Run this once in the Supabase SQL editor (Project → SQL Editor → New query).
--
-- Note: the Next.js app talks to Supabase ONLY from the server, using the
-- service role key, which bypasses Row Level Security entirely. RLS is
-- still enabled below (with no policies) as defense-in-depth, so the
-- public anon key — if it ever leaked — could not read or write anything.

create extension if not exists pgcrypto;

-- ── Blog posts ──────────────────────────────────────────────────────────
create table if not exists posts (
  id text primary key,                    -- slug, e.g. "she-uses-her-voice-like-a-tool"
  title text not null,
  subtitle text,
  category text not null,                 -- style | home | table | art | edit
  author text not null default 'Kizuri Afrika',
  date text not null,                     -- display string, e.g. "June 10, 2026"
  read_time text not null default '3 min read',
  image text,                             -- public Supabase Storage URL
  excerpt text,
  content text not null,                  -- HTML
  tags text[] not null default '{}',
  created_at timestamptz not null default now()
);

alter table posts enable row level security;

-- ── Comments ─────────────────────────────────────────────────────────────
create table if not exists comments (
  id uuid primary key default gen_random_uuid(),
  post_id text not null references posts(id) on delete cascade,
  name text not null,
  text text not null,
  approved boolean not null default false,
  created_at timestamptz not null default now()
);

create index if not exists comments_post_id_idx on comments(post_id);

alter table comments enable row level security;

-- ── Contact messages ─────────────────────────────────────────────────────
create table if not exists messages (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  email text not null,
  phone text,
  linkedin text,
  message text not null,
  created_at timestamptz not null default now()
);

alter table messages enable row level security;

-- ── Newsletter subscriptions ─────────────────────────────────────────────
create table if not exists subscriptions (
  id uuid primary key default gen_random_uuid(),
  email text not null unique,
  created_at timestamptz not null default now()
);

alter table subscriptions enable row level security;

-- ── Storage bucket for cover + inline blog images ────────────────────────
insert into storage.buckets (id, name, public)
values ('blog-images', 'blog-images', true)
on conflict (id) do nothing;
