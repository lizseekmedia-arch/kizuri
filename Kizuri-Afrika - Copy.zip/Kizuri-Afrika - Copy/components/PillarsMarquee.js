'use client';
import Link from 'next/link';

const PILLARS = [
  {
    key: 'style',
    letter: 'S',
    name: 'Style',
    tagline: 'Fashion & Adornment',
    desc: 'African fashion, bold prints, handcrafted jewellery, and the art of self-expression.',
    image: '/images/style.jpeg',
    className: 'pillar-style',
  },
  {
    key: 'home',
    letter: 'H',
    name: 'Home',
    tagline: 'Interiors & Décor',
    desc: 'Afro-bohemian interiors, warm textures, handcrafted ceramics, and intentional spaces.',
    image: '/images/pillar_home.png',
    className: 'pillar-home',
  },
  {
    key: 'table',
    letter: 'T',
    name: 'Table',
    tagline: 'Cuisine & Gathering',
    desc: 'African culinary arts, table styling, rich spices, and the sacred ritual of gathering.',
    image: '/images/table.jpeg',
    className: 'pillar-table',
  },
  {
    key: 'art',
    letter: 'A',
    name: 'Art',
    tagline: 'Craft & Expression',
    desc: "African craft, contemporary sculpture, visual storytelling, and creative soul.",
    image: '/images/pillar_art.png',
    className: 'pillar-art',
  },
  {
    key: 'edit',
    letter: 'E',
    name: 'The Edit',
    tagline: 'Perspectives & Voice',
    desc: 'Reflections, editorial profiles, cultural commentary, and the soul of the brand.',
    image: '/images/edit.jpeg',
    className: 'pillar-edit',
  },
];

const REVEAL_DELAYS = ['', 'reveal-delay-1', 'reveal-delay-2', 'reveal-delay-3', 'reveal-delay-4'];

export default function PillarsMarquee() {
  return (
    <section className="pillars" id="pillars">
      <div className="pillars-inner">
        <div className="pillars-header reveal">
          <span className="section-label" style={{ color: 'var(--gold)' }}>The World of Kizuri Afrika</span>
          <h2 className="pillars-title">Five expressions of the African good life.</h2>
          <p className="pillars-subtitle">
            Explore our five core pillars — each curated to inspire a life of depth, luxury, and authentic African heritage.
          </p>
          <div style={{ width: 60, height: 1, background: 'var(--gold)', margin: '24px auto 0' }} />
        </div>

        {/* LUXURY FEATURED GRID */}
        <div className="pillars-luxury-grid">
          {PILLARS.map((pillar, i) => (
            <Link
              key={pillar.key}
              href={`/blog?category=${pillar.key}`}
              className={`pillar-luxury-card ${revealClass(i)}`}
            >
              <div className="pillar-card-bg" style={{ backgroundImage: `url('${pillar.image}')` }} />
              <div className="pillar-card-overlay" />
              <div className="pillar-card-badge">{pillar.letter}</div>
              <div className="pillar-card-content">
                <span className="pillar-card-tagline">{pillar.tagline}</span>
                <h3 className="pillar-card-title">{pillar.name}</h3>
                <p className="pillar-card-desc">{pillar.desc}</p>
                <span className="pillar-card-cta">
                  Explore Stories
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <line x1="5" y1="12" x2="19" y2="12" />
                    <polyline points="12 5 19 12 12 19" />
                  </svg>
                </span>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}

function revealClass(index) {
  return `reveal ${REVEAL_DELAYS[index % 5]}`.trim();
}
