'use client';
import { useState } from 'react';
import { submitContactAction } from '../app/actions/contact';

const initialForm = { name: '', email: '', phone: '', linkedin: '', message: '' };

export default function ContactForm() {
  const [form, setForm] = useState(initialForm);
  const [status, setStatus] = useState('idle'); // idle | sending | sent
  const [error, setError] = useState('');

  function update(field) {
    return (e) => setForm((f) => ({ ...f, [field]: e.target.value }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (status === 'sending') return;

    setStatus('sending');
    setError('');
    const result = await submitContactAction(form);

    if (result.success) {
      setStatus('sent');
    } else {
      setStatus('idle');
      setError(result.error || 'Something went wrong. Please try again.');
    }
  }

  if (status === 'sent') {
    return (
      <div style={{ textAlign: 'center', padding: '24px 0' }}>
        <span className="section-label" style={{ color: 'var(--gold)', marginBottom: 16 }}>Message Sent</span>
        <h3 style={{ fontFamily: 'var(--serif)', fontSize: 28, fontWeight: 300, marginBottom: 16 }}>Thank You.</h3>
        <p style={{ fontSize: 15, color: '#5A5650', lineHeight: 1.6 }}>
          Your message has been received. We will get back to you at the email provided.
          For urgent inquiries, please contact us directly on WhatsApp.
        </p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit}>
      <div className="form-group">
        <label htmlFor="name">Full Name *</label>
        <input type="text" id="name" className="form-control" placeholder="Your name" required value={form.name} onChange={update('name')} disabled={status === 'sending'} />
      </div>

      <div className="form-group">
        <label htmlFor="email">Email Address *</label>
        <input type="email" id="email" className="form-control" placeholder="Your email address" required value={form.email} onChange={update('email')} disabled={status === 'sending'} />
      </div>

      <div className="form-group">
        <label htmlFor="phone">Phone Number (Optional)</label>
        <input type="tel" id="phone" className="form-control" placeholder="e.g. +254 711 434927" value={form.phone} onChange={update('phone')} disabled={status === 'sending'} />
      </div>

      <div className="form-group">
        <label htmlFor="linkedin">LinkedIn Profile Link (Optional)</label>
        <input type="url" id="linkedin" className="form-control" placeholder="e.g. linkedin.com/in/username" value={form.linkedin} onChange={update('linkedin')} disabled={status === 'sending'} />
      </div>

      <div className="form-group">
        <label htmlFor="message">Your Message *</label>
        <textarea id="message" className="form-control" placeholder="How can we walk together?" required value={form.message} onChange={update('message')} disabled={status === 'sending'} />
      </div>

      {error && <p style={{ color: '#d9534f', fontSize: 13, marginBottom: 16 }}>{error}</p>}

      <button
        type="submit"
        className="form-submit-btn"
        style={
          status === 'sending'
            ? { background: 'var(--gold)', borderColor: 'var(--gold)', color: 'var(--charcoal)' }
            : undefined
        }
      >
        {status === 'sending' ? 'Sending...' : 'Send Message'}
      </button>
    </form>
  );
}
