'use client';
import { useRef, useState } from 'react';
import { subscribeAction } from '../app/actions/subscribe';

export default function SubscribeForm() {
  const [email, setEmail] = useState('');
  const [state, setState] = useState('idle'); // idle | sending | done
  const inputRef = useRef(null);

  async function handleSubmit(e) {
    e.preventDefault();
    if (!email.trim() || state === 'sending') return;

    setState('sending');
    const result = await subscribeAction(email);

    if (result.success) {
      setState('done');
      setEmail('');
      setTimeout(() => setState('idle'), 4000);
    } else {
      setState('idle');
      alert(result.error || 'Something went wrong. Please try again.');
    }
  }

  return (
    <form className="email-form reveal reveal-delay-3" onSubmit={handleSubmit}>
      <input
        ref={inputRef}
        type="email"
        name="email"
        className="email-input"
        placeholder={state === 'done' ? 'You are welcome here.' : 'Your email address'}
        aria-label="Email address"
        required
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        disabled={state === 'sending'}
      />
      <button
        type="submit"
        className="email-btn"
        style={
          state === 'done'
            ? { background: 'var(--gold)', borderColor: 'var(--gold)', color: 'var(--charcoal)' }
            : undefined
        }
      >
        {state === 'done' ? 'Thank you.' : state === 'sending' ? 'Sending…' : 'Subscribe'}
      </button>
    </form>
  );
}
