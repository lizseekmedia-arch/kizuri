'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import DiasporaOrderModal from './DiasporaOrderModal';

export default function SiteNav() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [diasporaModalOpen, setDiasporaModalOpen] = useState(false);

  useEffect(() => {
    function onScroll() {
      setScrolled(window.scrollY > 80);
    }
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = menuOpen || diasporaModalOpen ? 'hidden' : '';
  }, [menuOpen, diasporaModalOpen]);

  useEffect(() => {
    function onKeyDown(e) {
      if (e.key === 'Escape') {
        setMenuOpen(false);
        setDiasporaModalOpen(false);
      }
    }
    document.addEventListener('keydown', onKeyDown);
    return () => document.removeEventListener('keydown', onKeyDown);
  }, []);

  const links = [
    { href: '/', label: 'Home' },
    { href: '/#about', label: 'About' },
    { href: '/#pillars', label: 'The World' },
    { href: '/blog', label: 'Blog' },
    { href: '/contact', label: 'Connect' },
  ];

  return (
    <>
      <nav
        id="main-nav"
        style={
          scrolled
            ? { padding: '16px 48px', boxShadow: '0 4px 32px rgba(0,0,0,0.08)', background: 'rgba(245, 242, 236, 0.95)' }
            : undefined
        }
      >
        <Link href="/" className="nav-wordmark">
          <img src="/images/kizuri weblogo.png" alt="Kizuri Afrika" className="nav-logo" />
        </Link>
        <div style={{ display: 'flex', alignItems: 'center', gap: 32 }}>
          <ul className="nav-links">
            {links.map((link) => (
              <li key={link.label}>
                <Link href={link.href}>{link.label}</Link>
              </li>
            ))}
          </ul>
          <button
            type="button"
            className="nav-diaspora-btn"
            style={{
              fontFamily: 'var(--sans)',
              fontSize: '10px',
              letterSpacing: '0.2em',
              textTransform: 'uppercase',
              padding: '8px 16px',
              border: '1px solid var(--gold)',
              background: 'transparent',
              color: 'var(--charcoal)',
              borderRadius: '2px',
              cursor: 'pointer',
              transition: 'all 0.3s ease',
            }}
            onClick={() => setDiasporaModalOpen(true)}
          >
            Diaspora Orders ✈
          </button>
        </div>
        <button
          className={`nav-hamburger${menuOpen ? ' open' : ''}`}
          aria-label="Toggle menu"
          aria-expanded={menuOpen}
          onClick={() => setMenuOpen((v) => !v)}
        >
          <span className="bar" />
          <span className="bar" />
          <span className="bar" />
        </button>
      </nav>

      <div className={`mobile-menu${menuOpen ? ' open' : ''}`} role="dialog" aria-modal="true" aria-label="Navigation menu">
        <ul>
          {links.map((link) => (
            <li key={link.label}>
              <Link href={link.href} className="mobile-nav-link" onClick={() => setMenuOpen(false)}>
                {link.label}
              </Link>
            </li>
          ))}
          <li style={{ marginTop: 16 }}>
            <button
              type="button"
              style={{
                fontFamily: 'var(--sans)',
                fontSize: '12px',
                letterSpacing: '0.2em',
                textTransform: 'uppercase',
                padding: '12px 24px',
                border: '1px solid var(--gold)',
                background: 'var(--gold)',
                color: 'var(--charcoal)',
                fontWeight: 500,
                cursor: 'pointer',
              }}
              onClick={() => {
                setMenuOpen(false);
                setDiasporaModalOpen(true);
              }}
            >
              Diaspora Orders ✈
            </button>
          </li>
        </ul>
        <div className="mobile-menu-rule" />
        <p className="mobile-menu-tagline">Living Beautifully The African Way</p>
      </div>

      {diasporaModalOpen && <DiasporaOrderModal onClose={() => setDiasporaModalOpen(false)} />}
    </>
  );
}
