'use client';
import { useState } from 'react';
import { submitCommentAction } from '../app/actions/comments';

export default function CommentForm({ postId }) {
  const [name, setName] = useState('');
  const [text, setText] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState('');

  async function handleSubmit(e) {
    e.preventDefault();
    if (!name.trim() || !text.trim() || sending) return;

    setSending(true);
    setError('');
    const result = await submitCommentAction({ postId, name, text });
    setSending(false);

    if (result.success) {
      setSubmitted(true);
    } else {
      setError(result.error || 'Something went wrong. Please try again.');
    }
  }

  if (submitted) {
    return (
      <div className="comment-form-wrapper">
        <h3>Leave a Comment</h3>
        <div
          style={{
            padding: 12,
            marginTop: 16,
            border: '1px solid var(--gold)',
            color: 'var(--gold)',
            textAlign: 'center',
            fontSize: 14,
          }}
        >
          Thank you. Your comment has been submitted and is awaiting moderation before showing up.
        </div>
      </div>
    );
  }

  return (
    <div className="comment-form-wrapper">
      <h3>Leave a Comment</h3>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="comment-name">Name *</label>
          <input
            type="text"
            id="comment-name"
            className="form-control"
            required
            placeholder="Your name"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
        </div>
        <div className="form-group">
          <label htmlFor="comment-text">Comment *</label>
          <textarea
            id="comment-text"
            className="form-control"
            required
            placeholder="Share your perspective..."
            value={text}
            onChange={(e) => setText(e.target.value)}
          />
        </div>
        {error && <p style={{ color: '#d9534f', fontSize: 13, marginBottom: 16 }}>{error}</p>}
        <button type="submit" className="form-submit-btn" disabled={sending}>
          {sending ? 'Posting…' : 'Post Comment'}
        </button>
      </form>
    </div>
  );
}
