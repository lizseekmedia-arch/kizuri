'use client';
import { useState } from 'react';
import { uploadImageAction } from '../../app/actions/upload';

export default function InlineImageModal({ onClose, onInsert }) {
  const [srcType, setSrcType] = useState('file');
  const [uploadedUrl, setUploadedUrl] = useState('');
  const [urlValue, setUrlValue] = useState('');
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState('');
  const [alt, setAlt] = useState('');
  const [caption, setCaption] = useState('');
  const [align, setAlign] = useState('center');

  const previewSrc = srcType === 'file' ? uploadedUrl : urlValue.trim();

  async function handleFileChange(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    setError('');
    setUploading(true);

    const formData = new FormData();
    formData.set('file', file);
    formData.set('folder', 'inline');
    const result = await uploadImageAction(formData);

    setUploading(false);
    if (result.success) {
      setUploadedUrl(result.url);
    } else {
      setError(result.error || 'Upload failed.');
    }
  }

  function handleSubmit(e) {
    e.preventDefault();
    const imgSrc = srcType === 'file' ? uploadedUrl : urlValue.trim();
    if (!imgSrc) {
      setError(srcType === 'file' ? 'Please select and wait for the image to finish uploading.' : 'Please enter an image URL / relative path.');
      return;
    }

    const alignmentClass = align === 'left' ? ' align-left' : align === 'right' ? ' align-right' : ' align-center';
    let html;
    if (caption.trim()) {
      html = `\n<figure class="post-inline-figure${alignmentClass}">\n  <img src="${imgSrc}" alt="${alt}" class="post-inline-img">\n  <figcaption>${caption.trim()}</figcaption>\n</figure>\n`;
    } else {
      html = `\n<img src="${imgSrc}" alt="${alt}" class="post-inline-img${alignmentClass}">\n`;
    }

    onInsert(html);
  }

  return (
    <div className="modal-overlay open" style={{ zIndex: 1100 }} onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="modal-content" style={{ maxWidth: 500, border: '1px solid rgba(200, 169, 81, 0.15)', background: '#1A1A18', boxShadow: '0 24px 64px rgba(0,0,0,0.6)' }}>
        <button type="button" className="modal-close" onClick={onClose}>&times;</button>
        <h2 className="modal-title" style={{ fontSize: 24, marginBottom: 24, color: '#fff', borderBottomColor: '#2a2a28', paddingBottom: 12, fontFamily: 'var(--serif)', fontWeight: 300 }}>
          Insert Inline Image
        </h2>

        <form onSubmit={handleSubmit}>
          <div className="form-group" style={{ marginBottom: 20 }}>
            <label style={{ color: '#aaa', fontSize: 10, marginBottom: 8, textTransform: 'uppercase', letterSpacing: '0.1em' }}>Image Source</label>
            <div style={{ display: 'flex', gap: 24, marginTop: 8 }}>
              <label style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer', color: '#fff', fontSize: 14 }}>
                <input type="radio" name="inline-src" checked={srcType === 'file'} onChange={() => setSrcType('file')} style={{ accentColor: 'var(--gold)' }} />
                Upload from PC
              </label>
              <label style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer', color: '#fff', fontSize: 14 }}>
                <input type="radio" name="inline-src" checked={srcType === 'url'} onChange={() => setSrcType('url')} style={{ accentColor: 'var(--gold)' }} />
                Image URL / Path
              </label>
            </div>
          </div>

          {srcType === 'file' ? (
            <div className="form-group" style={{ marginBottom: 20 }}>
              <label style={{ color: '#aaa', fontSize: 10, marginBottom: 8, textTransform: 'uppercase', letterSpacing: '0.1em' }}>Select Image *</label>
              <input type="file" className="form-control" accept="image/*" onChange={handleFileChange} disabled={uploading} />
              {uploading && <p style={{ color: 'var(--gold)', fontSize: 12, marginTop: 8 }}>Uploading…</p>}
            </div>
          ) : (
            <div className="form-group" style={{ marginBottom: 20 }}>
              <label style={{ color: '#aaa', fontSize: 10, marginBottom: 8, textTransform: 'uppercase', letterSpacing: '0.1em' }}>Image URL / Relative Path *</label>
              <input type="text" className="form-control" placeholder="e.g. /images/my-image.jpg or https://example.com/img.jpg" value={urlValue} onChange={(e) => setUrlValue(e.target.value)} />
            </div>
          )}

          {previewSrc && (
            <div style={{ marginBottom: 20, textAlign: 'center', border: '1px dashed rgba(200, 169, 81, 0.2)', padding: 12 }}>
              <img src={previewSrc} alt="" style={{ maxHeight: 120, maxWidth: '100%', objectFit: 'contain', borderRadius: 4 }} />
            </div>
          )}

          {error && <p style={{ color: '#d9534f', fontSize: 12, marginBottom: 16 }}>{error}</p>}

          <div className="form-group" style={{ marginBottom: 20 }}>
            <label style={{ color: '#aaa', fontSize: 10, marginBottom: 8, textTransform: 'uppercase', letterSpacing: '0.1em' }}>Alt Text (Description for Screen Readers)</label>
            <input type="text" className="form-control" placeholder="e.g. Shantal Kisimba speaking at the panel" value={alt} onChange={(e) => setAlt(e.target.value)} />
          </div>

          <div className="form-group" style={{ marginBottom: 20 }}>
            <label style={{ color: '#aaa', fontSize: 10, marginBottom: 8, textTransform: 'uppercase', letterSpacing: '0.1em' }}>Caption (Displayed under image)</label>
            <input type="text" className="form-control" placeholder="e.g. Shantal speaking in Nairobi, Kenya (June 2026)" value={caption} onChange={(e) => setCaption(e.target.value)} />
          </div>

          <div className="form-group" style={{ marginBottom: 24 }}>
            <label style={{ color: '#aaa', fontSize: 10, marginBottom: 8, textTransform: 'uppercase', letterSpacing: '0.1em' }}>Alignment / Layout</label>
            <select className="form-control" style={{ background: '#111', color: '#fff' }} value={align} onChange={(e) => setAlign(e.target.value)}>
              <option value="center">Centered (Full Width)</option>
              <option value="left">Float Left</option>
              <option value="right">Float Right</option>
            </select>
          </div>

          <button type="submit" className="form-submit-btn" style={{ background: 'var(--gold)', borderColor: 'var(--gold)', color: 'var(--charcoal)', fontWeight: 500 }} disabled={uploading}>
            Insert into Body
          </button>
        </form>
      </div>
    </div>
  );
}
