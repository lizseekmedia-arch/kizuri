'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { loginAction } from '../../app/actions/auth';

export default function LoginForm() {
  const router = useRouter();
  const [passcode, setPasscode] = useState('');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    if (submitting) return;
    setSubmitting(true);
    setError('');

    const result = await loginAction(passcode);

    if (result.success) {
      router.push('/admin');
      router.refresh();
    } else {
      setError(result.error || 'Incorrect passcode. Please try again.');
      setPasscode('');
      setSubmitting(false);
    }
  }

  return (
    <form onSubmit={handleSubmit}>
      <div className="form-group" style={{ marginBottom: 24 }}>
        <label
          htmlFor="admin-passcode"
          style={{ color: '#aaa', fontSize: 10, marginBottom: 8, textTransform: 'uppercase', letterSpacing: '0.1em' }}
        >
          Enter Passcode
        </label>
        <input
          type="password"
          id="admin-passcode"
          className="form-control"
          style={{ background: '#111', borderColor: '#333', textAlign: 'center', fontSize: 18, letterSpacing: '0.25em', color: '#fff' }}
          required
          placeholder="••••••••"
          value={passcode}
          onChange={(e) => setPasscode(e.target.value)}
          disabled={submitting}
          autoFocus
        />
      </div>
      <button
        type="submit"
        className="form-submit-btn"
        style={{ background: 'var(--gold)', borderColor: 'var(--gold)', color: 'var(--charcoal)', fontWeight: 500, letterSpacing: '0.2em' }}
        disabled={submitting}
      >
        {submitting ? 'Checking…' : 'Authorize'}
      </button>
      {error && (
        <p style={{ color: '#d9534f', fontSize: 12, marginTop: 16 }}>{error}</p>
      )}
    </form>
  );
}
