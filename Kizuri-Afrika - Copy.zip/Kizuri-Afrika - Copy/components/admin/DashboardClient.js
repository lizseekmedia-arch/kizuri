'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { CATEGORY_NAMES } from '../../lib/categories';
import { deletePostAction } from '../../app/actions/admin-posts';
import { setCommentApprovalAction, deleteCommentAction } from '../../app/actions/admin-comments';
import { deleteMessageAction } from '../../app/actions/admin-messages';
import { deleteSubscriptionAction } from '../../app/actions/admin-subscriptions';
import PostModal from './PostModal';

function formatDate(iso) {
  return new Date(iso).toLocaleString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
}

export default function DashboardClient({ posts, comments, messages, subscriptions }) {
  const router = useRouter();
  const [tab, setTab] = useState('posts');
  const [modalPost, setModalPost] = useState(undefined); // undefined = closed, null = new, object = editing

  const pending = comments.filter((c) => !c.approved).length;
  const approved = comments.filter((c) => c.approved).length;

  function refresh() {
    router.refresh();
  }

  async function handleDeletePost(id) {
    if (!confirm('Are you sure you want to delete this blog post? This action cannot be undone.')) return;
    const result = await deletePostAction(id);
    if (result.success) refresh();
    else alert(result.error);
  }

  async function handleToggleComment(id, approve) {
    const result = await setCommentApprovalAction(id, approve);
    if (result.success) refresh();
    else alert(result.error);
  }

  async function handleDeleteComment(id) {
    if (!confirm('Delete this comment permanently?')) return;
    const result = await deleteCommentAction(id);
    if (result.success) refresh();
    else alert(result.error);
  }

  async function handleDeleteMessage(id) {
    if (!confirm('Delete this inquiry permanently?')) return;
    const result = await deleteMessageAction(id);
    if (result.success) refresh();
    else alert(result.error);
  }

  async function handleDeleteSubscription(id) {
    if (!confirm('Delete this subscriber permanently?')) return;
    const result = await deleteSubscriptionAction(id);
    if (result.success) refresh();
    else alert(result.error);
  }

  return (
    <main className="admin-wrapper">
      <div className="admin-header-row">
        <div>
          <h1 className="admin-page-title">Dashboard</h1>
          <p style={{ color: 'var(--warm-mid)', fontSize: 12, textTransform: 'uppercase', letterSpacing: '0.1em', marginTop: 4 }}>
            Manage Content &amp; Moderation
          </p>
        </div>
        <div style={{ display: 'flex', gap: 12 }}>
          <button className="admin-btn admin-btn-primary" onClick={() => setModalPost(null)}>New Blog Post</button>
        </div>
      </div>

      <section className="admin-stats-grid">
        <div className="stat-card">
          <span className="stat-title">Total Posts</span>
          <span className="stat-value">{posts.length}</span>
        </div>
        <div className="stat-card">
          <span className="stat-title">Total Comments</span>
          <span className="stat-value">{comments.length}</span>
        </div>
        <div className="stat-card">
          <span className="stat-title">Pending Moderation</span>
          <span className="stat-value" style={{ color: 'var(--gold)' }}>{pending}</span>
        </div>
        <div className="stat-card">
          <span className="stat-title">Approved Comments</span>
          <span className="stat-value" style={{ color: '#5cb85c' }}>{approved}</span>
        </div>
        <div className="stat-card">
          <span className="stat-title">Inquiries Received</span>
          <span className="stat-value" style={{ color: 'var(--gold)' }}>{messages.length}</span>
        </div>
        <div className="stat-card">
          <span className="stat-title">Total Subscribers</span>
          <span className="stat-value" style={{ color: 'var(--gold)' }}>{subscriptions.length}</span>
        </div>
      </section>

      <div className="admin-tabs">
        <button className={`admin-tab${tab === 'posts' ? ' active' : ''}`} onClick={() => setTab('posts')}>Blog Posts</button>
        <button className={`admin-tab${tab === 'comments' ? ' active' : ''}`} onClick={() => setTab('comments')}>Comments Moderation</button>
        <button className={`admin-tab${tab === 'messages' ? ' active' : ''}`} onClick={() => setTab('messages')}>Contact Messages</button>
        <button className={`admin-tab${tab === 'subscriptions' ? ' active' : ''}`} onClick={() => setTab('subscriptions')}>Subscribers</button>
      </div>

      {tab === 'posts' && (
        <section className="admin-panel active">
          <div className="table-wrapper">
            <table className="admin-table">
              <thead>
                <tr>
                  <th>Title</th>
                  <th>Category</th>
                  <th>Publish Date</th>
                  <th>Read Time</th>
                  <th style={{ textAlign: 'right' }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {posts.length === 0 ? (
                  <tr><td colSpan={5} style={{ textAlign: 'center', color: 'var(--warm-mid)', fontStyle: 'italic' }}>No posts found. Create one.</td></tr>
                ) : (
                  posts.map((post) => (
                    <tr key={post.id}>
                      <td style={{ fontWeight: 400, color: '#fff' }}>{post.title}</td>
                      <td>{CATEGORY_NAMES[post.category] || post.category}</td>
                      <td>{post.date}</td>
                      <td>{post.read_time || '3 min read'}</td>
                      <td style={{ textAlign: 'right' }} className="admin-actions">
                        <span className="action-link" onClick={() => setModalPost(post)}>Edit</span>
                        <span className="action-link danger" onClick={() => handleDeletePost(post.id)}>Delete</span>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </section>
      )}

      {tab === 'comments' && (
        <section className="admin-panel active">
          <div className="table-wrapper">
            <table className="admin-table">
              <thead>
                <tr>
                  <th>Commenter</th>
                  <th>Comment Description</th>
                  <th>Article Title</th>
                  <th>Date Posted</th>
                  <th>Status</th>
                  <th style={{ textAlign: 'right' }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {comments.length === 0 ? (
                  <tr><td colSpan={6} style={{ textAlign: 'center', color: 'var(--warm-mid)', fontStyle: 'italic' }}>No comments found.</td></tr>
                ) : (
                  comments.map((comment) => {
                    const relatedPost = posts.find((p) => p.id === comment.post_id);
                    const snippet = comment.text.length > 60 ? `${comment.text.substring(0, 60)}...` : comment.text;
                    return (
                      <tr key={comment.id}>
                        <td style={{ color: '#fff', fontWeight: 400 }}>{comment.name}</td>
                        <td>{snippet}</td>
                        <td>{relatedPost ? relatedPost.title : 'Deleted Post'}</td>
                        <td>{formatDate(comment.created_at)}</td>
                        <td>
                          {comment.approved
                            ? <span style={{ color: '#5cb85c', fontSize: 11, textTransform: 'uppercase' }}>Approved</span>
                            : <span style={{ color: 'var(--gold)', fontSize: 11, textTransform: 'uppercase' }}>Pending</span>}
                        </td>
                        <td style={{ textAlign: 'right' }} className="admin-actions">
                          {comment.approved
                            ? <span className="action-link" onClick={() => handleToggleComment(comment.id, false)}>Unapprove</span>
                            : <span className="action-link" style={{ color: '#5cb85c' }} onClick={() => handleToggleComment(comment.id, true)}>Approve</span>}
                          <span className="action-link danger" onClick={() => handleDeleteComment(comment.id)}>Delete</span>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </section>
      )}

      {tab === 'messages' && (
        <section className="admin-panel active">
          <div className="table-wrapper">
            <table className="admin-table">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Phone</th>
                  <th>LinkedIn</th>
                  <th>Message</th>
                  <th>Date</th>
                  <th style={{ textAlign: 'right' }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {messages.length === 0 ? (
                  <tr><td colSpan={7} style={{ textAlign: 'center', color: 'var(--warm-mid)', fontStyle: 'italic' }}>No inquiries received yet.</td></tr>
                ) : (
                  messages.map((msg) => (
                    <tr key={msg.id}>
                      <td style={{ color: '#fff', fontWeight: 400, whiteSpace: 'nowrap' }}>{msg.name}</td>
                      <td><a href={`mailto:${msg.email}`} style={{ color: 'var(--gold)', textDecoration: 'none' }}>{msg.email}</a></td>
                      <td style={{ whiteSpace: 'nowrap' }}>{msg.phone || '—'}</td>
                      <td>{msg.linkedin ? <a href={msg.linkedin} target="_blank" rel="noopener noreferrer" style={{ color: 'var(--gold)', textDecoration: 'none' }}>Link</a> : '—'}</td>
                      <td style={{ maxWidth: 300, wordWrap: 'break-word', whiteSpace: 'normal' }}>{msg.message}</td>
                      <td style={{ whiteSpace: 'nowrap' }}>{formatDate(msg.created_at)}</td>
                      <td style={{ textAlign: 'right' }} className="admin-actions">
                        <span className="action-link danger" onClick={() => handleDeleteMessage(msg.id)}>Delete</span>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </section>
      )}

      {tab === 'subscriptions' && (
        <section className="admin-panel active">
          <div className="table-wrapper">
            <table className="admin-table">
              <thead>
                <tr>
                  <th>Email Address</th>
                  <th>Date Subscribed</th>
                  <th style={{ textAlign: 'right' }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {subscriptions.length === 0 ? (
                  <tr><td colSpan={3} style={{ textAlign: 'center', color: 'var(--warm-mid)', fontStyle: 'italic' }}>No subscribers yet.</td></tr>
                ) : (
                  subscriptions.map((sub) => (
                    <tr key={sub.id}>
                      <td style={{ color: '#fff', fontWeight: 400 }}><a href={`mailto:${sub.email}`} style={{ color: 'var(--gold)', textDecoration: 'none' }}>{sub.email}</a></td>
                      <td>{formatDate(sub.created_at)}</td>
                      <td style={{ textAlign: 'right' }} className="admin-actions">
                        <span className="action-link danger" onClick={() => handleDeleteSubscription(sub.id)}>Delete</span>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </section>
      )}

      {modalPost !== undefined && (
        <PostModal
          post={modalPost}
          onClose={() => setModalPost(undefined)}
          onSaved={() => {
            setModalPost(undefined);
            refresh();
          }}
        />
      )}
    </main>
  );
}
