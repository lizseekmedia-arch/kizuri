'use client';
import { useRef, useState } from 'react';
import { savePostAction } from '../../app/actions/admin-posts';
import { uploadImageAction } from '../../app/actions/upload';
import InlineImageModal from './InlineImageModal';

const today = () => new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });

function emptyForm() {
  return {
    title: '',
    subtitle: '',
    category: 'style',
    image: '',
    date: today(),
    readTime: '4 min read',
    excerpt: '',
    content: '',
    tags: '',
  };
}

function postToForm(post) {
  return {
    title: post.title || '',
    subtitle: post.subtitle || '',
    category: post.category || 'style',
    image: post.image || '',
    date: post.date || '',
    readTime: post.read_time || '',
    excerpt: post.excerpt || '',
    content: post.content || '',
    tags: (post.tags || []).join(', '),
  };
}

export default function PostModal({ post, onClose, onSaved }) {
  const isEdit = Boolean(post);
  const [form, setForm] = useState(() => (post ? postToForm(post) : emptyForm()));
  const [coverUploading, setCoverUploading] = useState(false);
  const [inlineModalOpen, setInlineModalOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const contentRef = useRef(null);

  function set(field) {
    return (e) => setForm((f) => ({ ...f, [field]: e.target.value }));
  }

  async function handleCoverUpload(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    setCoverUploading(true);
    setError('');

    const formData = new FormData();
    formData.set('file', file);
    formData.set('folder', 'covers');
    const result = await uploadImageAction(formData);

    setCoverUploading(false);
    if (result.success) {
      setForm((f) => ({ ...f, image: result.url }));
    } else {
      setError(result.error || 'Cover image upload failed.');
    }
  }

  function insertAtCursor(text) {
    const textarea = contentRef.current;
    if (!textarea) return;
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const oldValue = form.content;
    const newValue = oldValue.substring(0, start) + text + oldValue.substring(end);
    setForm((f) => ({ ...f, content: newValue }));
    requestAnimationFrame(() => {
      textarea.focus();
      textarea.selectionStart = textarea.selectionEnd = start + text.length;
    });
  }

  function insertQuote() {
    const textarea = contentRef.current;
    const selected = textarea ? form.content.substring(textarea.selectionStart, textarea.selectionEnd) : '';
    insertAtCursor(`\n<blockquote>${selected || 'Quote goes here'}</blockquote>\n`);
  }

  function insertParagraph() {
    const textarea = contentRef.current;
    const selected = textarea ? form.content.substring(textarea.selectionStart, textarea.selectionEnd) : '';
    insertAtCursor(`\n<p>${selected || 'Paragraph text goes here...'}</p>\n`);
  }

  function formatAutoParagraphs() {
    let raw = form.content.trim();
    if (!raw) return;

    // Check if content already consists of HTML tags
    if (!raw.includes('<p>') && !raw.includes('<h1') && !raw.includes('<h2')) {
      const blocks = raw.split(/\n\s*\n/);
      const formatted = blocks
        .map((block) => {
          const trimmed = block.trim();
          if (!trimmed) return '';
          if (trimmed.startsWith('<blockquote>') || trimmed.startsWith('<img') || trimmed.startsWith('<figure')) {
            return trimmed;
          }
          return `<p>${trimmed.replace(/\n/g, '<br />')}</p>`;
        })
        .filter(Boolean)
        .join('\n\n');
      setForm((f) => ({ ...f, content: formatted }));
    } else {
      // Clean up extra line breaks between tags
      setForm((f) => ({ ...f, content: raw }));
    }
  }

  function insertHeading(level) {
    const textarea = contentRef.current;
    const selected = textarea ? form.content.substring(textarea.selectionStart, textarea.selectionEnd) : '';
    insertAtCursor(`\n<h${level}>${selected || 'Section Heading'}</h${level}>\n`);
  }

  function insertFormat(tag) {
    const textarea = contentRef.current;
    const selected = textarea ? form.content.substring(textarea.selectionStart, textarea.selectionEnd) : '';
    insertAtCursor(`<${tag}>${selected || 'text'}</${tag}>`);
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (saving) return;
    setSaving(true);
    setError('');

    const tags = form.tags ? form.tags.split(',').map((t) => t.trim()).filter(Boolean) : [];
    const result = await savePostAction({ ...form, tags }, isEdit ? post.id : null);

    setSaving(false);
    if (result.success) {
      onSaved();
    } else {
      setError(result.error || 'Something went wrong.');
    }
  }

  return (
    <div className="modal-overlay open" onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="modal-content" style={{ maxWidth: 760 }}>
        <button className="modal-close" onClick={onClose}>&times;</button>
        <h2 className="modal-title">{isEdit ? 'Edit Blog Post' : 'New Blog Post'}</h2>

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="post-title">Blog Title *</label>
            <input type="text" id="post-title" className="form-control" required placeholder="e.g. She Uses Her Voice Like a Tool" value={form.title} onChange={set('title')} />
          </div>

          <div className="form-group">
            <label htmlFor="post-subtitle">Subtitle / Headline *</label>
            <input type="text" id="post-subtitle" className="form-control" required placeholder="e.g. A Profile of Shantal Kisimba" value={form.subtitle} onChange={set('subtitle')} />
          </div>

          <div className="form-group">
            <label htmlFor="post-category">Category Pillar *</label>
            <select id="post-category" className="form-control" required style={{ background: '#111', color: '#fff' }} value={form.category} onChange={set('category')}>
              <option value="style">Style</option>
              <option value="home">Home</option>
              <option value="table">Table</option>
              <option value="art">Art</option>
              <option value="edit">The Kizuri Edit</option>
            </select>
          </div>

          <div className="form-group">
            <label htmlFor="post-image">Cover Image Path/URL *</label>
            <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
              <input type="text" id="post-image" className="form-control" required placeholder="e.g. /images/edit.jpeg" style={{ flex: 1 }} value={form.image} onChange={set('image')} />
              <label className="admin-btn" style={{ margin: 0, padding: '16px 20px', whiteSpace: 'nowrap', cursor: 'pointer', textAlign: 'center', display: 'inline-flex', alignItems: 'center', gap: 6, borderColor: 'var(--gold)', color: 'var(--gold)' }}>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ verticalAlign: 'middle' }}>
                  <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                  <polyline points="17 8 12 3 7 8" />
                  <line x1="12" y1="3" x2="12" y2="15" />
                </svg>
                {coverUploading ? 'Uploading…' : 'Upload File'}
                <input type="file" accept="image/*" style={{ display: 'none' }} onChange={handleCoverUpload} disabled={coverUploading} />
              </label>
            </div>
            {form.image && (
              <div style={{ marginTop: 12, textAlign: 'center', border: '1px dashed rgba(200, 169, 81, 0.3)', padding: 12, position: 'relative' }}>
                <img src={form.image} alt="" style={{ maxHeight: 150, maxWidth: '100%', objectFit: 'contain', borderRadius: 4 }} />
                <button type="button" className="modal-close" style={{ position: 'absolute', top: 8, right: 8, fontSize: 18, lineHeight: 1 }} onClick={() => setForm((f) => ({ ...f, image: '' }))}>&times;</button>
              </div>
            )}
          </div>

          <div className="form-group" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
            <div>
              <label htmlFor="post-date">Publish Date *</label>
              <input type="text" id="post-date" className="form-control" required placeholder="e.g. June 10, 2026" value={form.date} onChange={set('date')} />
            </div>
            <div>
              <label htmlFor="post-readtime">Read Time *</label>
              <input type="text" id="post-readtime" className="form-control" required placeholder="e.g. 5 min read" value={form.readTime} onChange={set('readTime')} />
            </div>
          </div>

          <div className="form-group">
            <label htmlFor="post-excerpt">Excerpt / Short Description *</label>
            <input type="text" id="post-excerpt" className="form-control" required placeholder="A brief hook (1-2 sentences) to display on lists." value={form.excerpt} onChange={set('excerpt')} />
          </div>

          <div className="form-group">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
              <label htmlFor="post-content" style={{ margin: 0 }}>Story Body *</label>
              <button
                type="button"
                className="admin-btn"
                style={{ padding: '4px 10px', fontSize: 10, borderColor: 'var(--gold)', color: 'var(--gold)', background: 'rgba(200,169,81,0.1)' }}
                onClick={formatAutoParagraphs}
                title="Click to automatically turn plain text line breaks into HTML paragraph tags"
              >
                ✨ Auto-Format Plain Text to Paragraphs
              </button>
            </div>
            <div style={{ display: 'flex', gap: 6, background: '#171715', padding: '8px 12px', border: '1px solid #333', borderBottom: 'none', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap' }}>
              <span style={{ fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.1em', color: 'var(--warm-mid)' }}>Toolbar:</span>
              <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                <button type="button" className="admin-btn" style={{ padding: '4px 8px', fontSize: 10, margin: 0 }} onClick={() => insertHeading(2)}>H2</button>
                <button type="button" className="admin-btn" style={{ padding: '4px 8px', fontSize: 10, margin: 0 }} onClick={() => insertHeading(3)}>H3</button>
                <button type="button" className="admin-btn" style={{ padding: '4px 8px', fontSize: 10, margin: 0 }} onClick={insertParagraph}>Paragraph</button>
                <button type="button" className="admin-btn" style={{ padding: '4px 8px', fontSize: 10, margin: 0 }} onClick={() => insertFormat('strong')}>Bold</button>
                <button type="button" className="admin-btn" style={{ padding: '4px 8px', fontSize: 10, margin: 0 }} onClick={() => insertFormat('em')}>Italics</button>
                <button type="button" className="admin-btn" style={{ padding: '4px 8px', fontSize: 10, margin: 0 }} onClick={insertQuote}>Quote</button>
                <button type="button" className="admin-btn" style={{ padding: '4px 10px', fontSize: 10, margin: 0, borderColor: 'var(--gold)', color: 'var(--gold)', display: 'inline-flex', alignItems: 'center', gap: 4 }} onClick={() => setInlineModalOpen(true)}>
                  📷 Insert Image
                </button>
              </div>
            </div>
            <textarea
              id="post-content"
              ref={contentRef}
              className="form-control"
              required
              placeholder={'Paste or type your article here. Click "✨ Auto-Format Plain Text to Paragraphs" to format plain text automatically!'}
              style={{ minHeight: 280, fontFamily: 'monospace', borderTop: 'none', lineHeight: '1.6' }}
              value={form.content}
              onChange={set('content')}
            />
          </div>

          <div className="form-group">
            <label htmlFor="post-tags">Tags (Comma separated)</label>
            <input type="text" id="post-tags" className="form-control" placeholder="e.g. KizuriAfrika, TheKizuriEdit, MentalHealth" value={form.tags} onChange={set('tags')} />
          </div>

          {error && <p style={{ color: '#d9534f', fontSize: 13, marginBottom: 16 }}>{error}</p>}

          <button type="submit" className="form-submit-btn" disabled={saving || coverUploading}>
            {saving ? 'Saving…' : 'Save Post'}
          </button>
        </form>
      </div>

      {inlineModalOpen && (
        <InlineImageModal
          onClose={() => setInlineModalOpen(false)}
          onInsert={(html) => {
            insertAtCursor(html);
            setInlineModalOpen(false);
          }}
        />
      )}
    </div>
  );
}
