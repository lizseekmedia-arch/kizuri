'use client';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { logoutAction } from '../../app/actions/auth';

export default function AdminNav() {
  const router = useRouter();

  async function handleLogout() {
    await logoutAction();
    router.push('/admin/login');
    router.refresh();
  }

  return (
    <nav id="main-nav" className="admin-navbar">
      <Link href="/" className="nav-wordmark">
        <img src="/images/kizuri weblogo.png" alt="Kizuri Afrika" className="nav-logo" />
        <span className="nav-admin-tag">&middot; Admin</span>
      </Link>
      <ul className="nav-links">
        <li><Link href="/">View Site</Link></li>
        <li><Link href="/blog">View Journal</Link></li>
        <li><a href="#" style={{ color: 'var(--gold)' }} onClick={(e) => { e.preventDefault(); handleLogout(); }}>Log Out</a></li>
      </ul>
    </nav>
  );
}
