import Link from 'next/link';
import { CATEGORY_NAMES } from '../lib/categories';

export default function PostCard({ post, revealClass = 'reveal' }) {
  return (
    <Link href={`/blog/${post.id}`} className={`blog-post-card ${revealClass}`.trim()}>
      <div className="card-img-wrapper">
        <span className="card-category">{CATEGORY_NAMES[post.category] || post.category}</span>
        <img src={post.image || '/images/hero_bg.png'} alt={post.title} />
      </div>
      <div className="card-body">
        <div className="card-meta">
          <span>{post.date}</span>
          <span>&middot;</span>
          <span>{post.read_time || '3 min read'}</span>
        </div>
        <h3 className="card-title">{post.title}</h3>
        <p className="card-excerpt">{post.excerpt || ''}</p>
        <div className="card-readmore">
          Read Story
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <line x1="5" y1="12" x2="19" y2="12" />
            <polyline points="12 5 19 12 12 19" />
          </svg>
        </div>
      </div>
    </Link>
  );
}
