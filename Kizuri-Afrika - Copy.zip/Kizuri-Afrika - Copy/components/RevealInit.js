'use client';
import { useRevealOnScroll } from '../lib/useReveal';

// Mount this once per page (in a Server Component tree) to enable the
// scroll-reveal fade-in on any element with class "reveal".
export default function RevealInit({ deps = [] }) {
  useRevealOnScroll(deps);
  return null;
}
