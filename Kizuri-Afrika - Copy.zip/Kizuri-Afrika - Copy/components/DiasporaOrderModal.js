'use client';
import { useState } from 'react';
import { submitContactAction } from '../app/actions/contact';

const PRODUCTS = [
  { id: 'custom-garment', name: 'Custom African Attire / Fashion Piece', priceUSD: 180, priceEUR: 165, priceGBP: 140, priceKES: 23500 },
  { id: 'home-decor', name: 'Afro-Bohemian Living & Home Décor Set', priceUSD: 240, priceEUR: 220, priceGBP: 185, priceKES: 31000 },
  { id: 'art-piece', name: 'Kizuri Afrika Fine Art & Craft Collectible', priceUSD: 350, priceEUR: 320, priceGBP: 270, priceKES: 45000 },
  { id: 'table-collection', name: 'African Culinary & Tableware Collection', priceUSD: 120, priceEUR: 110, priceGBP: 95, priceKES: 15500 },
  { id: 'bespoke-inquiry', name: 'Bespoke Custom Order / Multiple Items', priceUSD: 0, priceEUR: 0, priceGBP: 0, priceKES: 0 },
];

const CURRENCIES = [
  { code: 'USD', symbol: '$', label: 'USD ($)' },
  { code: 'GBP', symbol: '£', label: 'GBP (£)' },
  { code: 'EUR', symbol: '€', label: 'EUR (€)' },
  { code: 'KES', symbol: 'KSh', label: 'KES (KSh)' },
];

const COUNTRIES = [
  'United States',
  'United Kingdom',
  'Canada',
  'Germany',
  'France',
  'Netherlands',
  'United Arab Emirates',
  'Australia',
  'Kenya',
  'Other International Country',
];

export default function DiasporaOrderModal({ onClose }) {
  const [currency, setCurrency] = useState('USD');
  const [selectedProduct, setSelectedProduct] = useState(PRODUCTS[0].id);
  const [country, setCountry] = useState('United States');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [notes, setNotes] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');

  const curr = CURRENCIES.find((c) => c.code === currency) || CURRENCIES[0];
  const prod = PRODUCTS.find((p) => p.id === selectedProduct) || PRODUCTS[0];

  function getPriceDisplay() {
    if (prod.priceUSD === 0) return 'Custom Quote';
    if (currency === 'USD') return `$${prod.priceUSD}`;
    if (currency === 'EUR') return `€${prod.priceEUR}`;
    if (currency === 'GBP') return `£${prod.priceGBP}`;
    return `KSh ${prod.priceKES.toLocaleString()}`;
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (!name || !email) {
      setError('Please provide your name and email.');
      return;
    }

    setSubmitting(true);
    setError('');

    const orderDetails = `[DIASPORA ORDER INQUIRY & PAYMENTS]
Item: ${prod.name}
Est. Price: ${getPriceDisplay()}
Destination: ${country}
Currency Preference: ${currency}
Client Phone: ${phone}
Notes / Sizes / Custom Requirements: ${notes || 'None'}`;

    const res = await submitContactAction({
      name: name.trim(),
      email: email.trim(),
      phone: phone.trim(),
      linkedin: `Diaspora Order (${currency})`,
      message: orderDetails,
    });

    setSubmitting(false);
    if (res.success) {
      setSuccess(true);
    } else {
      setError(res.error || 'Could not process order request. Please try again or contact us via WhatsApp.');
    }
  }

  const waMessage = encodeURIComponent(
    `Hi Liz! I'm ordering from the Diaspora (${country}). Item: ${prod.name} (${getPriceDisplay()}). Name: ${name || 'Customer'}.`
  );
  const waUrl = `https://wa.me/254711434927?text=${waMessage}`;

  return (
    <div className="modal-overlay open" style={{ zIndex: 1200 }} onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="modal-content" style={{ maxWidth: 640, background: '#171715', border: '1px solid var(--gold)', boxShadow: '0 32px 80px rgba(0,0,0,0.8)' }}>
        <button type="button" className="modal-close" onClick={onClose}>&times;</button>

        <div style={{ textAlign: 'center', marginBottom: 24 }}>
          <span className="section-label" style={{ color: 'var(--gold)', fontSize: 10 }}>Global Shipping & Payments</span>
          <h2 className="modal-title" style={{ fontSize: 28, marginBottom: 8 }}>Diaspora International Orders</h2>
          <p style={{ fontSize: 13, color: 'var(--warm-mid)' }}>
            We package and ship worldwide. Select your currency and item below to place your order or request custom shipping.
          </p>
        </div>

        {success ? (
          <div style={{ textAlign: 'center', padding: '32px 16px' }}>
            <div style={{ fontSize: 48, color: 'var(--gold)', marginBottom: 16 }}>✓</div>
            <h3 style={{ fontFamily: 'var(--serif)', fontSize: 24, marginBottom: 12, color: '#fff' }}>Order Received</h3>
            <p style={{ fontSize: 14, color: 'rgba(245,242,236,0.8)', marginBottom: 24, lineHeight: 1.6 }}>
              Thank you for ordering with Kizuri Afrika! We have received your order details for <strong>{prod.name}</strong> ({country}). Our team will send your secure payment invoice and shipping schedule to <strong>{email}</strong> shortly.
            </p>
            <div style={{ display: 'flex', gap: 12, justifyContent: 'center' }}>
              <a href={waUrl} target="_blank" rel="noopener noreferrer" className="admin-btn" style={{ background: 'var(--gold)', borderColor: 'var(--gold)', color: 'var(--charcoal)', textDecoration: 'none', fontWeight: 500 }}>
                Instant Pay & Chat on WhatsApp
              </a>
              <button type="button" className="admin-btn" onClick={onClose}>Close</button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit}>
            {/* Currency Selector */}
            <div className="form-group" style={{ marginBottom: 20 }}>
              <label style={{ color: 'var(--gold)', fontSize: 11, textTransform: 'uppercase', letterSpacing: '0.1em' }}>Select Your Preferred Currency</label>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 8, marginTop: 8 }}>
                {CURRENCIES.map((c) => (
                  <button
                    key={c.code}
                    type="button"
                    style={{
                      padding: '10px 8px',
                      background: currency === c.code ? 'var(--gold)' : '#222',
                      color: currency === c.code ? '#111' : '#fff',
                      border: '1px solid var(--gold)',
                      borderRadius: 4,
                      cursor: 'pointer',
                      fontSize: 12,
                      fontWeight: currency === c.code ? 600 : 400,
                    }}
                    onClick={() => setCurrency(c.code)}
                  >
                    {c.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Product Selector */}
            <div className="form-group" style={{ marginBottom: 20 }}>
              <label style={{ color: '#aaa', fontSize: 11, textTransform: 'uppercase', letterSpacing: '0.1em' }}>Select Product / Collection</label>
              <select className="form-control" style={{ background: '#111', color: '#fff' }} value={selectedProduct} onChange={(e) => setSelectedProduct(e.target.value)}>
                {PRODUCTS.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} — {p.priceUSD === 0 ? 'Custom Quote' : currency === 'USD' ? `$${p.priceUSD}` : currency === 'EUR' ? `€${p.priceEUR}` : currency === 'GBP' ? `£${p.priceGBP}` : `KSh ${p.priceKES.toLocaleString()}`}
                  </option>
                ))}
              </select>
            </div>

            <div className="form-group" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
              <div>
                <label style={{ color: '#aaa', fontSize: 11, textTransform: 'uppercase', letterSpacing: '0.1em' }}>Your Full Name *</label>
                <input type="text" className="form-control" required placeholder="e.g. Elizabeth Olago" value={name} onChange={(e) => setName(e.target.value)} />
              </div>
              <div>
                <label style={{ color: '#aaa', fontSize: 11, textTransform: 'uppercase', letterSpacing: '0.1em' }}>Email Address *</label>
                <input type="email" className="form-control" required placeholder="e.g. hello@kizuriafrika.com" value={email} onChange={(e) => setEmail(e.target.value)} />
              </div>
            </div>

            <div className="form-group" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
              <div>
                <label style={{ color: '#aaa', fontSize: 11, textTransform: 'uppercase', letterSpacing: '0.1em' }}>Destination Country *</label>
                <select className="form-control" style={{ background: '#111', color: '#fff' }} value={country} onChange={(e) => setCountry(e.target.value)}>
                  {COUNTRIES.map((c) => (
                    <option key={c} value={c}>{c}</option>
                  ))}
                </select>
              </div>
              <div>
                <label style={{ color: '#aaa', fontSize: 11, textTransform: 'uppercase', letterSpacing: '0.1em' }}>WhatsApp / Phone Number</label>
                <input type="text" className="form-control" placeholder="e.g. +1 555 123 4567" value={phone} onChange={(e) => setPhone(e.target.value)} />
              </div>
            </div>

            <div className="form-group" style={{ marginBottom: 24 }}>
              <label style={{ color: '#aaa', fontSize: 11, textTransform: 'uppercase', letterSpacing: '0.1em' }}>Sizing / Customization Notes</label>
              <textarea className="form-control" rows={3} placeholder="Specify sizes, color preferences, delivery timeline, or additional items..." value={notes} onChange={(e) => setNotes(e.target.value)} />
            </div>

            {error && <p style={{ color: '#d9534f', fontSize: 12, marginBottom: 16 }}>{error}</p>}

            <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
              <button type="submit" className="form-submit-btn" style={{ flex: 1, background: 'var(--gold)', borderColor: 'var(--gold)', color: 'var(--charcoal)', fontWeight: 500 }} disabled={submitting}>
                {submitting ? 'Processing Order…' : `Place Order (${getPriceDisplay()})`}
              </button>
              <a href={waUrl} target="_blank" rel="noopener noreferrer" className="admin-btn" style={{ padding: '16px 20px', textDecoration: 'none', display: 'inline-flex', alignItems: 'center', gap: 6, borderColor: 'var(--gold)', color: 'var(--gold)' }}>
                WhatsApp Direct
              </a>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
