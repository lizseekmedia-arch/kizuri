const defaultBlogPosts = [
  {
    id: "she-uses-her-voice-like-a-tool",
    title: "She Uses Her Voice Like a Tool",
    subtitle: "A Profile of Shantal Kisimba — Environmental Scientist, Mental Health Advocate & Digital Storyteller",
    category: "edit",
    author: "Kizuri Afrika",
    date: "June 10, 2026",
    readTime: "5 min read",
    image: "images/edit.jpeg",
    excerpt: "There are people who talk about change. And then there are people who have decided, quietly and with great determination, to become it. Shantal Kisimba is the second kind.",
    content: `<p>There are people who talk about change. And then there are people who have decided, quietly and with great determination, to become it.</p>
<p>Shantal Kisimba is the second kind.</p>
<p>Based in Kenya, Shantal carries many titles — Environmental Scientist, Mental Health Advocate, Youth Mentor, Human Rights Advocate, Graphic Designer and Digital Advocacy Strategist. But what ties all of these together is something simpler and more powerful than any title: a voice she has chosen to use with intention, in service of conversations that matter.</p>
<p>Her advocacy journey began not in a lecture hall or a boardroom — but in curiosity. As far back as 2017, Shantal found herself drawn to the study of the human mind, human behaviour and human emotions. What started as intellectual passion deepened into something far more personal. Years later, she was diagnosed with depression, anxiety disorder and psychosis.</p>
<blockquote>"When I started feeling better and getting myself back," she shares, "I decided to take my digital advocacy to the next level — using my personal story as a tool for impact and awareness on mental health challenges."</blockquote>
<p>That decision — to transform pain into purpose, to turn a diagnosis into a platform — is the foundation of everything Shantal has built.</p>
<p>Mental health advocacy in Africa carries a particular weight. In many communities, the conversation has barely begun. Stigma runs deep — shaped by culture, by silence, by the belief that some things are simply not spoken of. Shantal has chosen to speak anyway. And in doing so, she has given thousands of people permission to do the same.</p>
<p>But her advocacy does not stop there.</p>
<p>As a professional Environmental Scientist, Shantal brings the rigour of her training to the urgent conversation around environmental conservation — using knowledge and education to amplify the case for a healthier planet. Her commitment to Human Rights is rooted in a belief that is both simple and radical: that every human being deserves a safe, secure and peaceful existence, and that this should never be up for debate.</p>
<p>And then there is her work with young people.</p>
<p>"I am one of those individuals who believe every young person carries greatness," she says. "All they need is someone believing in them and leading them."</p>
<p>That belief — in the innate greatness of every young African — is one that Kizuri Afrika Living holds at the very core of its mission. We exist, in part, for the generation of Africans who will grow up in the world we are building together. Shantal's work and ours are rooted in the same soil.</p>
<p>On African cultural identity, Shantal speaks with the quiet confidence of someone who has thought deeply about what it means to be African in the modern world.</p>
<p>"Diverse cultures tied together with common threads — that is what makes us Africans. This is our pride, our uniqueness, our identity."</p>
<p>And on mental wellness — a topic she has fought to bring from the margins to the centre of African public conversation — her message is clear and urgent: "Thriving is tied to embracing conversations around mental wellness. If we all understood that, then mental wellness would be the centre of our everyday Africa — and this would mean a better and thriving Africa."</p>
<p>Perhaps most beautifully of all, when asked what living beautifully the African way means to her, Shantal offered this:</p>
<blockquote>"Living beautifully the African way means being unapologetically and authentically us — without shying away. By doing that, the light in us is projected to the world. As Africans, we have so much in us."</blockquote>
<p>We could not have said it better ourselves.</p>
<p>At Kizuri Afrika Living, living beautifully the African way is not an aesthetic. It is a philosophy — an active, daily choice to inhabit your culture with pride, to bring your whole self to every room you enter, and to refuse to dim your light for anyone.</p>
<p>Shantal Kisimba is a woman who has done exactly that — even on the days when it cost her something.</p>
<p>That, to us, is the definition of living beautifully.</p>
<p><strong>Follow Shantal Kisimba and connect with her work:</strong></p>
<ul>
  <li><strong>LinkedIn:</strong> <a href="https://linkedin.com/in/shantal-kisimba-13b133146" target="_blank" rel="noopener noreferrer">linkedin.com/in/shantal-kisimba-13b133146</a></li>
  <li><strong>Facebook:</strong> <a href="https://facebook.com/shaz.kish" target="_blank" rel="noopener noreferrer">facebook.com/shaz.kish</a></li>
  <li><strong>Instagram:</strong> <a href="https://instagram.com/shantal.kisimba" target="_blank" rel="noopener noreferrer">@shantal.kisimba</a></li>
  <li><strong>Blog & Resources:</strong> <a href="https://selar.co/m/shantal-kisimba1" target="_blank" rel="noopener noreferrer">selar.co/m/shantal-kisimba1</a></li>
</ul>
<p>If you or someone you know is struggling with mental health, Shantal's platforms are a safe, honest and compassionate space to begin the conversation. You are not alone.</p>`,
    tags: [
      "KizuriAfrika",
      "TheKizuriEdit",
      "ShantalKisimba",
      "AfricanWomen",
      "MentalHealthAfrica",
      "AfricanVoices",
      "YouthEmpowerment",
      "HumanRights",
      "LivingBeautifullyTheAfricanWay"
    ]
  }
];
